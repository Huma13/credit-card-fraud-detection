"""Streamlit demo: score transactions with the trained model.

Run:  streamlit run app.py     (after `python -m src.train ...` has created results/model.joblib)
"""
import os

import joblib
import pandas as pd
import streamlit as st

from src.data import FEATURES, TARGET

st.set_page_config(page_title="Credit Card Fraud Detector", page_icon="💳", layout="wide")
st.title("💳 Credit Card Fraud Detector")

MODEL_PATH = "results/model.joblib"
DATA_PATH = "data/creditcard.csv"

if not os.path.exists(MODEL_PATH):
    st.error("No trained model found. Run `python -m src.train --data data/creditcard.csv` first.")
    st.stop()

art = joblib.load(MODEL_PATH)
st.caption(f"Model: **{art['name']}**  |  decision threshold: **{art['threshold']:.3f}**")

source = st.radio("Input", ["Random sample from dataset", "Upload CSV"], horizontal=True)
df = None
if source == "Upload CSV":
    f = st.file_uploader("CSV with columns Time, V1..V28, Amount", type="csv")
    if f:
        df = pd.read_csv(f)
else:
    if os.path.exists(DATA_PATH):
        n = st.slider("Number of transactions", 50, 2000, 500, step=50)
        full = pd.read_csv(DATA_PATH)
        fraud_boost = st.checkbox("Guarantee some fraud cases in the sample", value=True)
        if fraud_boost:
            df = pd.concat([full[full[TARGET] == 1].sample(min(10, int(full[TARGET].sum()))),
                            full.sample(n)]).drop_duplicates().reset_index(drop=True)
        else:
            df = full.sample(n).reset_index(drop=True)
    else:
        st.warning(f"{DATA_PATH} not found. Upload a CSV instead.")

if df is not None:
    missing = set(FEATURES) - set(df.columns)
    if missing:
        st.error(f"Missing columns: {sorted(missing)}")
        st.stop()
    proba = art["model"].predict_proba(art["preprocessor"].transform(df))[:, 1]
    out = df.copy()
    out["fraud_probability"] = proba
    out["flagged"] = proba >= art["threshold"]

    c1, c2, c3 = st.columns(3)
    c1.metric("Transactions scored", f"{len(out):,}")
    c2.metric("Flagged as fraud", int(out["flagged"].sum()))
    if TARGET in out:
        tp = int((out["flagged"] & (out[TARGET] == 1)).sum())
        c3.metric("Actual frauds caught", f"{tp} / {int(out[TARGET].sum())}")

    st.subheader("Flagged transactions")
    show = ["fraud_probability", "Amount", "Time"] + ([TARGET] if TARGET in out else [])
    st.dataframe(out[out["flagged"]][show].sort_values("fraud_probability", ascending=False),
                 use_container_width=True)
    with st.expander("All scored transactions"):
        st.dataframe(out, use_container_width=True)
