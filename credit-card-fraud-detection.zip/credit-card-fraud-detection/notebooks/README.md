Put your EDA notebook here (`eda.ipynb`). Suggested cells:
class balance bar chart; Amount/Time histograms by class; correlation of V1..V28 with Class;
PCA pair plots of the most correlated components (e.g. V14, V17, V12, V10) coloured by class.
