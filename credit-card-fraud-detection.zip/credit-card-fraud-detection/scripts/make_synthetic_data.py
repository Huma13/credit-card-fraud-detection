"""Create a small fake dataset with the same schema as Kaggle's creditcard.csv.

Only for debugging the pipeline when you don't have the real file handy.
Do NOT report results from this in your write-up.
"""
import sys

import numpy as np
import pandas as pd

out = sys.argv[1] if len(sys.argv) > 1 else "data/synthetic.csv"
n, fraud_rate = 60000, 0.004
rng = np.random.default_rng(0)
y = (rng.random(n) < fraud_rate).astype(int)
X = rng.normal(size=(n, 28))
X[y == 1, :6] += rng.normal(loc=2.0, scale=1.0, size=(y.sum(), 6))   # separable signal
df = pd.DataFrame(X, columns=[f"V{i}" for i in range(1, 29)])
df.insert(0, "Time", np.sort(rng.integers(0, 172800, size=n)))
df["Amount"] = np.round(rng.lognormal(3.0, 1.2, size=n), 2)
df["Class"] = y
df.to_csv(out, index=False)
print(f"wrote {out}: {n} rows, {y.sum()} fraud")
