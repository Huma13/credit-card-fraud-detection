"""Model definitions."""
import warnings

# sklearn >= 1.8 deprecates `penalty=`; it is still required on older versions.
warnings.filterwarnings("ignore", message=".*penalty.*")

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

try:
    from xgboost import XGBClassifier
except ImportError:  # xgboost is optional
    XGBClassifier = None

ALL_MODELS = ["logreg", "logreg_poly_l1", "rf", "xgboost", "mlp"]


def build_model(name, seed=42, class_weight=False, pos_weight=1.0, fast=False):
    """Build an untrained model. Returns None if the combination is unsupported."""
    cw = "balanced" if class_weight else None

    if name == "logreg":
        return LogisticRegression(max_iter=2000, class_weight=cw)

    if name == "logreg_poly_l1":
        # Quadratic + interaction terms (~500 features) with LASSO, as in the paper
        return make_pipeline(
            PolynomialFeatures(degree=2, include_bias=False),
            StandardScaler(),
            LogisticRegression(penalty="l1", solver="liblinear", C=0.1,
                               max_iter=200, class_weight=cw),
        )

    if name == "rf":
        return RandomForestClassifier(
            n_estimators=100 if fast else 300,
            n_jobs=-1,
            random_state=seed,
            class_weight="balanced_subsample" if class_weight else None,
        )

    if name == "xgboost":
        if XGBClassifier is None:
            return None
        return XGBClassifier(
            n_estimators=150 if fast else 400,
            max_depth=4,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="aucpr",
            n_jobs=-1,
            random_state=seed,
            scale_pos_weight=pos_weight if class_weight else 1.0,
        )

    if name == "mlp":
        if class_weight:  # sklearn's MLP has no class_weight option
            return None
        return MLPClassifier(
            hidden_layer_sizes=(32, 16),
            early_stopping=True,
            max_iter=200,
            random_state=seed,
        )

    raise ValueError(f"Unknown model: {name}")
