"""Sweep the target minority proportion p (reproduces Figure 2 of the CS229 report).

Usage: python -m src.sweep_p --data data/creditcard.csv
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score

from src.data import Preprocessor, TARGET, load_data, split_data
from src.sampling import get_sampler

P_VALUES = [0.005, 0.01, 0.02, 0.05, 0.1, 0.25, 0.5]

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/creditcard.csv")
ap.add_argument("--outdir", default="results")
ap.add_argument("--seed", type=int, default=42)
args = ap.parse_args()

train, val, _ = split_data(load_data(args.data), args.seed)
prep = Preprocessor().fit(train)
Xtr, ytr = prep.transform(train), train[TARGET].to_numpy()
Xva, yva = prep.transform(val), val[TARGET].to_numpy()

base = LogisticRegression(max_iter=2000).fit(Xtr, ytr)
base_ap = average_precision_score(yva, base.predict_proba(Xva)[:, 1])

rows = []
for strat in ["over", "under", "smote"]:
    for p in P_VALUES:
        Xr, yr = get_sampler(strat, p, args.seed).fit_resample(Xtr, ytr)
        m = LogisticRegression(max_iter=2000).fit(Xr, yr)
        auprc = average_precision_score(yva, m.predict_proba(Xva)[:, 1])
        rows.append({"strategy": strat, "p": p, "val_auprc": auprc})
        print(f"{strat:6s} p={p:<6} AUPRC={auprc:.4f}")

df = pd.DataFrame(rows)
os.makedirs(args.outdir, exist_ok=True)
df.to_csv(os.path.join(args.outdir, "sweep_p.csv"), index=False)

plt.figure(figsize=(6, 4))
for strat, g in df.groupby("strategy"):
    plt.plot(g["p"], g["val_auprc"], marker="o", label=strat)
plt.axhline(base_ap, color="gray", ls="--", label="no sampling")
plt.xscale("log")
plt.xlabel("Minority proportion p")
plt.ylabel("Validation AUPRC")
plt.title("Effect of resampling ratio (logistic regression)")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(args.outdir, "sweep_p.png"), dpi=150)
