"""Run the full experiment: models x imbalance strategies.

Protocol (mirrors the CS229 report's "tournament"):
  1. Train every (model, strategy) pair on the TRAIN split, score on VALIDATION (AUPRC).
  2. Pick the best strategy per model.
  3. Choose a decision threshold on validation (max F1).
  4. Evaluate each finalist once on the untouched TEST split.

Usage:
    python -m src.train --data data/creditcard.csv
    python -m src.train --data data/creditcard.csv --fast          # quick smoke run
    python -m src.train --data data/creditcard.csv --models rf xgboost
"""
import argparse
import os
import time

import joblib
import numpy as np
import pandas as pd

from src.data import Preprocessor, TARGET, load_data, split_data
from src.evaluate import (best_f1_threshold, compute_metrics, plot_confusion,
                          plot_pr_curves)
from src.models import ALL_MODELS, build_model
from src.sampling import STRATEGIES, get_sampler


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/creditcard.csv")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--models", nargs="+", default=ALL_MODELS, choices=ALL_MODELS)
    ap.add_argument("--strategies", nargs="+", default=STRATEGIES, choices=STRATEGIES)
    ap.add_argument("--p", type=float, default=0.02,
                    help="target minority-class fraction after resampling")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--fast", action="store_true",
                    help="subsample legit training rows and use smaller models")
    return ap.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    np.random.seed(args.seed)

    df = load_data(args.data)
    train, val, test = split_data(df, args.seed)
    print(f"Split sizes  train={len(train):,}  val={len(val):,}  test={len(test):,}")
    print(f"Fraud counts train={train[TARGET].sum()}  val={val[TARGET].sum()}  test={test[TARGET].sum()}")

    if args.fast:
        legit = train[train[TARGET] == 0].sample(30000, random_state=args.seed)
        train = pd.concat([legit, train[train[TARGET] == 1]]).sample(frac=1, random_state=args.seed)

    prep = Preprocessor().fit(train)
    Xtr, ytr = prep.transform(train), train[TARGET].to_numpy()
    Xva, yva = prep.transform(val), val[TARGET].to_numpy()
    Xte, yte = prep.transform(test), test[TARGET].to_numpy()
    pos_weight = (ytr == 0).sum() / max((ytr == 1).sum(), 1)

    rows, best = [], {}   # best[model] = dict(model, val_proba, strategy, auprc)
    for mname in args.models:
        for strat in args.strategies:
            model = build_model(mname, args.seed, class_weight=(strat == "class_weight"),
                                pos_weight=pos_weight, fast=args.fast)
            if model is None:
                continue
            sampler = get_sampler(strat, args.p, args.seed)
            Xfit, yfit = (sampler.fit_resample(Xtr, ytr) if sampler else (Xtr, ytr))

            t0 = time.time()
            model.fit(Xfit, yfit)
            proba = model.predict_proba(Xva)[:, 1]
            m = compute_metrics(yva, proba)
            secs = time.time() - t0
            print(f"[{mname:15s} | {strat:12s}] val AUPRC={m['auprc']:.4f} "
                  f"AUROC={m['auroc']:.4f}  ({secs:.0f}s)")
            rows.append({"model": mname, "strategy": strat, "val_auprc": m["auprc"],
                         "val_auroc": m["auroc"], "train_seconds": round(secs, 1)})
            if mname not in best or m["auprc"] > best[mname]["auprc"]:
                best[mname] = {"model": model, "strategy": strat,
                               "auprc": m["auprc"], "val_proba": proba}

    val_df = pd.DataFrame(rows)
    val_df.to_csv(os.path.join(args.outdir, "validation_results.csv"), index=False)
    print("\nValidation grid (AUPRC):")
    print(val_df.pivot(index="model", columns="strategy", values="val_auprc").round(4))

    # ---- Final evaluation on the untouched test set ----
    test_rows, curves, test_proba = [], {}, {}
    for mname, b in best.items():
        proba = b["model"].predict_proba(Xte)[:, 1]
        thr = best_f1_threshold(yva, b["val_proba"])      # threshold from VALIDATION only
        label = f"{mname} ({b['strategy']})"
        curves[label] = (yte, proba)
        test_proba[mname] = (proba, thr)
        for thr_name, t in (("0.5", 0.5), ("tuned", thr)):
            m = compute_metrics(yte, proba, t)
            test_rows.append({"model": mname, "strategy": b["strategy"],
                              "threshold_type": thr_name, **m})
        plot_confusion(yte, proba, thr,
                       os.path.join(args.outdir, f"confusion_{mname}.png"),
                       f"{label}, thr={thr:.3f}")

    test_df = pd.DataFrame(test_rows)
    test_df.to_csv(os.path.join(args.outdir, "test_results.csv"), index=False)
    plot_pr_curves(curves, os.path.join(args.outdir, "pr_curves_test.png"))
    print("\nTest results:")
    cols = ["model", "strategy", "threshold_type", "auprc", "auroc",
            "precision", "recall", "f1", "tp", "fp", "fn"]
    print(test_df[cols].round(4).to_string(index=False))

    # ---- Save the overall winner for the demo app ----
    winner = max(best, key=lambda k: best[k]["auprc"])
    artifact = {"model": best[winner]["model"], "preprocessor": prep,
                "threshold": test_proba[winner][1], "name": f"{winner} ({best[winner]['strategy']})"}
    joblib.dump(artifact, os.path.join(args.outdir, "model.joblib"))
    print(f"\nSaved best model by validation AUPRC: {artifact['name']} -> {args.outdir}/model.joblib")


if __name__ == "__main__":
    main()
