"""Resampling strategies for the class imbalance problem.

All samplers are applied to the TRAINING split only (never to val/test),
otherwise duplicated/synthetic rows leak into evaluation and inflate scores.
"""
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler

# "class_weight" does no resampling; the model itself is re-weighted (see models.py)
STRATEGIES = ["none", "class_weight", "over", "under", "smote"]


def get_sampler(name: str, p: float = 0.02, seed: int = 42):
    """Return a sampler that makes the minority class a fraction `p` of the data.

    imblearn expects minority/majority ratio: p / (1 - p).
    """
    ratio = p / (1 - p)
    if name in ("none", "class_weight"):
        return None
    if name == "over":
        return RandomOverSampler(sampling_strategy=ratio, random_state=seed)
    if name == "under":
        return RandomUnderSampler(sampling_strategy=ratio, random_state=seed)
    if name == "smote":
        return SMOTE(sampling_strategy=ratio, random_state=seed)
    raise ValueError(f"Unknown sampling strategy: {name}")
