"""Data loading, stratified splitting and preprocessing."""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

PCA_COLS = [f"V{i}" for i in range(1, 29)]
FEATURES = ["Time"] + PCA_COLS + ["Amount"]
TARGET = "Class"


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = set(FEATURES + [TARGET]) - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing columns: {sorted(missing)}")
    return df


def split_data(df: pd.DataFrame, seed: int = 42):
    """Stratified 2/3 train, 1/6 validation, 1/6 test split (same as the CS229 report)."""
    train, rest = train_test_split(
        df, test_size=1 / 3, stratify=df[TARGET], random_state=seed
    )
    val, test = train_test_split(
        rest, test_size=0.5, stratify=rest[TARGET], random_state=seed
    )
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)


class Preprocessor:
    """Scales Time and log(1+Amount). V1..V28 are already PCA-standardised.

    Fit on the training split only, then reuse for validation/test/new data.
    """

    def __init__(self):
        self.scaler = StandardScaler()

    @staticmethod
    def _raw(df):
        return np.column_stack([df["Time"].to_numpy(), np.log1p(df["Amount"].to_numpy())])

    def fit(self, df):
        self.scaler.fit(self._raw(df))
        return self

    def transform(self, df) -> pd.DataFrame:
        X = df[FEATURES].copy()
        X[["Time", "Amount"]] = self.scaler.transform(self._raw(df))
        return X
